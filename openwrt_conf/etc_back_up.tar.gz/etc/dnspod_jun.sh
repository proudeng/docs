#!/bin/sh

#ACCOUNT="proudeng@gmail.com"
#PASSWORD="lovexiaoshe"
#DOMAIN="proudj.com"
#SUBDOMAIN="home"
#RECORD_LINE=""

#DOMAIN_ID="1168680"
#RECORD_LIST="91999963"


dnspod_domain_get_id(){
        options="login_email=${ACCOUNT}&login_password=${PASSWORD}";
        out=$(curl -s -k https://dnsapi.cn/Domain.List -d ${options});
    for line in $out;do
        if [ $(echo $line|grep '<id>' |wc -l) != 0 ];then
            DOMAIN_ID=${line%<*};
            DOMAIN_ID=${DOMAIN_ID#*>};
            #echo "domain id: $DOMAIN_ID";
        fi
        if [ $(echo $line|grep '<name>' |wc -l) != 0 ];then
            DOMAIN_NAME=${line%<*};
            DOMAIN_NAME=${DOMAIN_NAME#*>};
            #echo "domain name: $DOMAIN_NAME";
            if [ "$DOMAIN_NAME" = "$DOMAIN" ];then
               break;
            fi
        fi
    done
        out=$(curl -s -k https://dnsapi.cn/Record.List -d "${options}&domain_id=${DOMAIN_ID}")
    for line in $out;do
        if [ $(echo $line|grep '<id>' |wc -l) != 0 ];then
            RECORD_ID=${line%<*};
            RECORD_ID=${RECORD_ID#*>};
            #echo "record id: $RECORD_ID";
        fi
        if [ $(echo $line|grep '<name>' |wc -l) != 0 ];then
            RECORD_NAME=${line%<*};
            RECORD_NAME=${RECORD_NAME#*>};
            #echo "record name: $RECORD_NAME";
            if [ "$RECORD_NAME" = "$SUBDOMAIN" ];then
               break;
            fi
        fi
    done
    echo "$RECORD_NAME:$RECORD_ID"
}


#
#Format is "Address 1: 117.89.152.129"
record_ip=`nslookup home.proudj.com |tail -n 1 |cut -d " " -f 3`;

#
#Format is "    inet 117.89.152.129 peer 61.155.116.217/32 scope global pppoe-wan"
current_ip=`ip addr show pppoe-wan |grep global|cut -d " " -f 6`;

if [ "$record_ip" = "$current_ip" ]; then
	echo "[`date`] IP address of wan did not change in 15 minutes: $record_ip";
	exit 0;
fi


curl -s -k --interface pppoe-wan https://dnsapi.cn/Record.Ddns -d "login_token=11003,2336559b0816d45eaa403c1184b0f9d6&domain_id=1168680&record_id=91999963&sub_domain=home&record_line=默认&value=$current_ip";


echo "[`date`] IP address of wan changed in 15 minutes and record updated: $record_ip -> $current_ip";
exit 0;


