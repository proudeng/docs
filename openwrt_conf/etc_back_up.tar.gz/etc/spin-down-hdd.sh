#!/bin/sh
#use this script to set the auto spin-down timeout for my Hitachi HDD only on Openwrt
#do not use this script for anyother devices on anyother platform.
#jun_deng@outlook.com

#usage: ./spin-down-hdd.sh


#parameter check
if [ "$#" != 0 ];then
        echo "param error."
        exit 0
fi

#UUID for my Hitachi HDD is 'edf432c5-cbdf-4d50-a76f-1f7246e264f8'
#use openwrt specific command 'block' to get the device name

DEVICE=`block info |grep 'edf432c5-cbdf-4d50-a76f-1f7246e264f8' |awk -F: '{print $1}'`

if [ -z "$DEVICE" ];then
echo "no Hitachi HDD found.exit!"
exit 0
fi

#set auto spin-down timeout timer to 20minuts
echo "Hitachi HDD found and mounted!"
echo "auto spin-down timer setted to 20 minutes!"

hdparm -S 240 $DEVICE

exit 0
